package com.TaskManager.TaskManager.repository;


import com.TaskManager.TaskManager.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task, Long> {
    long countByStatus(String status);
}
