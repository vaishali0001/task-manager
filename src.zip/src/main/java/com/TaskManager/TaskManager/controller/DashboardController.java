package com.TaskManager.TaskManager.controller;


import com.TaskManager.TaskManager.repository.ProjectRepository;
import com.TaskManager.TaskManager.repository.TaskRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@CrossOrigin("*")
public class DashboardController {

    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;

    @GetMapping("/stats")
    public Map<String, Long> getStats() {

        Map<String, Long> stats = new HashMap<>();

        stats.put("totalProjects", projectRepository.count());

        stats.put("totalTasks", taskRepository.count());

        stats.put(
                "completedTasks",
                taskRepository.countByStatus("COMPLETED")
        );

        stats.put(
                "pendingTasks",
                taskRepository.countByStatus("PENDING")
        );

        return stats;
    }
}