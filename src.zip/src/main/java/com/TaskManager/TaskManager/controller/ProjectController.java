package com.TaskManager.TaskManager.controller;

import com.TaskManager.TaskManager.entity.Project;
import com.TaskManager.TaskManager.service.ProjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
@RequiredArgsConstructor
@CrossOrigin("*")
public class ProjectController {

    private final ProjectService projectService;

    @PostMapping
    public Project create(@RequestBody Project project) {
        return projectService.create(project);
    }

    @GetMapping
    public List<Project> getAll() {
        return projectService.getAll();
    }

    @PutMapping("/{id}")
    public Project update(
            @PathVariable Long id,
            @RequestBody Project project
    ) {
        return projectService.update(id, project);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        projectService.delete(id);
    }
}