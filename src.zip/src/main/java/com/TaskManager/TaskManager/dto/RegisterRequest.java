package com.TaskManager.TaskManager.dto;


import com.TaskManager.TaskManager.enums.Role;
import lombok.Data;

@Data
public class RegisterRequest {

    private String name;
    private String email;
    private String password;
    private Role role;
}